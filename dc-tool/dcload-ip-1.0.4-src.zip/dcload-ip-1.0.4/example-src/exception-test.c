int main(void)
{
    int i;

    i = *((volatile unsigned int *)2);
}
    

    
