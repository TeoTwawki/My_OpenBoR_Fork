#ifndef __BSWAP_H__
#define __BSWAP_H__

unsigned short bswap16(unsigned short x);
unsigned int bswap32(unsigned int x);

#endif
