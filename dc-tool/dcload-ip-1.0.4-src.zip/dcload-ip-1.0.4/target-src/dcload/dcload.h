#ifndef __DCLOAD_H__
#define __DCLOAD_H__

extern unsigned int booted;
extern void disp_info(void);
extern void disp_status(const char * status);
extern unsigned int running;

#endif
