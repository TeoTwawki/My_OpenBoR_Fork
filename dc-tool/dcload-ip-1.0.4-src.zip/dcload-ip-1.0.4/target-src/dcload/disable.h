#ifndef __DISABLE_H__
#define __DISABLE_H__

void disable_cache(void);

#endif
