#ifndef __LAN_ADAPTER_H__
#define __LAN_ADAPTER_H__

#include "adapter.h"

extern adapter_t adapter_la;

#endif
