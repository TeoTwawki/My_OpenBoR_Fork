#ifndef __CDFS_H__
#define __CDFS_H__

void cdfs_redir_enable(void);
void cdfs_redir_save(void);
void cdfs_redir_disable(void);
void cdfs_redir_enable(void);

#endif
