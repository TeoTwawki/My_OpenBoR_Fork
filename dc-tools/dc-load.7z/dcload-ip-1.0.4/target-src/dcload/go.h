#ifndef __GO_H__
#define __GO_H__

void go(unsigned int addr);

#endif
